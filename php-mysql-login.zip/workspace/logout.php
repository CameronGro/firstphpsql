<?php
  error_reporting(E_ALL & ~E_NOTICE);
  session_start();
  session_destroy();


?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>title</title>
  </head>
  <body>
      <a href="index.php"> Click here to return to home page.</a>
  </body>
</html>